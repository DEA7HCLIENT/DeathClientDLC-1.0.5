package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import java.util.concurrent.ThreadLocalRandom;

/** Particle trail behind the player. */
public class TrailsModule extends Module {
    public final NumberSetting style = add(Fx.styleSetting());
    public final NumberSetting amount = add(new NumberSetting("Amount", 2, 1, 6, 1));
    public final BoolSetting onlyMoving = add(new BoolSetting("Only moving", true));

    public TrailsModule() { super("Trails", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (onlyMoving.get() && p.getVelocity().horizontalLengthSquared() < 1.0E-4) return;
        var effect = Fx.style(style);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < (int) amount.get(); i++) {
            Fx.spawn(c, effect, p.getX() + (r.nextDouble() - 0.5) * 0.5, p.getY() + 0.1, p.getZ() + (r.nextDouble() - 0.5) * 0.5);
        }
    }
}
