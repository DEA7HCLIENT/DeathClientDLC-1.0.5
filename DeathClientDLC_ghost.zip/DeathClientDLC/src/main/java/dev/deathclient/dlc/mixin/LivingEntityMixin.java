package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ModuleManager;
import dev.deathclient.dlc.SwingAnimationModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    // require = 0: if the target method differs in this build the injection is skipped instead of crashing.
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$swingDuration(CallbackInfoReturnable<Integer> cir) {
        SwingAnimationModule m = ModuleManager.get(SwingAnimationModule.class);
        if (m != null && m.isEnabled() && (Object) this == MinecraftClient.getInstance().player) {
            cir.setReturnValue(m.duration());
        }
    }
}
