package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;

/** Overrides the field of view while enabled and restores it afterwards. */
public class FovModule extends Module {
    public final NumberSetting fov = add(new NumberSetting("FOV", 100, 30, 110, 5));
    private Integer old;

    public FovModule() { super("FOV", Category.VISUALS); }

    @Override
    protected void onEnable() {
        old = MinecraftClient.getInstance().options.getFov().getValue();
    }

    @Override
    public void onTick(MinecraftClient c) {
        int want = (int) fov.get();
        if (c.options.getFov().getValue().intValue() != want) c.options.getFov().setValue(want);
    }

    @Override
    protected void onDisable() {
        if (old != null) MinecraftClient.getInstance().options.getFov().setValue(old);
    }
}
