package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * Target ESP with a custom image (textures/gui/target.png). The picture is drawn over the nearest
 * target (same pick as KillAura) and spins around its center. Drawn as a screen overlay: the
 * target's position is projected to the screen, so it needs no world-render hook.
 */
public class TargetEspImageModule extends Module {
    private static final Identifier TEXTURE = Identifier.of("deathclientdlc", "textures/gui/target.png");
    private static final int TEX = 512;

    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 20, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.5, 2.5, 0.1));
    /** Degrees per second. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 180, 30, 720, 30));
    public final BoolSetting reverse = add(new BoolSetting("Reverse", false));
    public final BoolSetting pulse = add(new BoolSetting("Pulse", true));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));

    private LivingEntity target;

    public TargetEspImageModule() { super("Target ESP Image", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        LivingEntity best = null;
        double bestDist = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            double d = p.distanceTo(le);
            if (d <= bestDist) { bestDist = d; best = le; }
        }
        target = best;
    }

    @Override
    protected void onDisable() { target = null; }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetEspImageModule m = ModuleManager.get(TargetEspImageModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        LivingEntity t = m.target;
        if (t == null || !t.isAlive()) return;
        m.draw(ctx, c, t, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, LivingEntity t, float delta) {
        ClientPlayerEntity p = c.player;

        // Camera: the player's eye, pushed back in third person (vanilla distance is 4 blocks).
        float yaw = p.getYaw(delta), pitch = p.getPitch(delta);
        Vec3d eye = p.getLerpedPos(delta).add(0, p.getEyeHeight(p.getPose()), 0);
        var persp = c.options.getPerspective();
        if (!persp.isFirstPerson()) {
            if (persp.isFrontView()) { yaw += 180f; pitch = -pitch; }
            double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
            Vec3d look = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
            eye = eye.subtract(look.multiply(4.0)); // camera sits 4 blocks behind its own view direction
        }

        // Target center, interpolated between ticks.
        Vec3d pos = t.getLerpedPos(delta).add(0, t.getHeight() * 0.5, 0);
        Vec3d d = pos.subtract(eye);

        // World -> camera space.
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr), rz = -Math.sin(yr);                 // right vector (y = 0)
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;   // up = right x forward
        double depth = d.x * fx + d.y * fy + d.z * fz;
        if (depth < 0.1) return; // behind the camera
        double sx = d.x * rx + d.z * rz;
        double sy = d.x * ux + d.y * uy + d.z * uz;

        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
        double px = sw / 2.0 + (sx / (depth * tan * sw / sh)) * (sw / 2.0);
        double py = sh / 2.0 - (sy / (depth * tan)) * (sh / 2.0);

        // Size follows the target's apparent size on screen.
        double world = Math.max(t.getWidth(), t.getHeight() * 0.7) * 1.7 * size.get();
        double pixels = world / (depth * tan) * (sh / 2.0);
        if (pulse.get()) pixels *= 1.0 + 0.06 * Math.sin(System.nanoTime() / 2.5e8);
        pixels = Math.max(14, Math.min(pixels, sh * 0.8));

        double dir = reverse.get() ? -1 : 1;
        float angle = (float) Math.toRadians(((System.nanoTime() / 1.0e9) * speed.get() * dir) % 360.0);
        int color = themeColor.get() ? Theme.current().accent() | 0xFF000000 : 0xFFFFFFFF;
        int half = (int) Math.round(pixels / 2.0);
        if (half < 1) return;

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) px, (float) py);
        m.rotate(angle);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, -half, -half, 0f, 0f,
                half * 2, half * 2, TEX, TEX, TEX, TEX, color);
        m.popMatrix();
    }
}
