package dev.deathclient.dlc;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), VISUALS("Visuals"), MISC("Misc");

    public final String label;
    Category(String label) { this.label = label; }
}
