package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * China Hat: a cone of particles above your head. A glowing rim plus spokes that run from the rim
 * to the tip; the spokes rotate. Visible in third person (hidden in first person by default).
 */
public class ChinaHatModule extends Module {
    public final NumberSetting style = add(Fx.styleSetting());
    public final NumberSetting radius = add(new NumberSetting("Radius", 0.7, 0.3, 1.5, 0.05));
    public final NumberSetting height = add(new NumberSetting("Height", 0.45, 0.2, 1.0, 0.05));
    public final NumberSetting points = add(new NumberSetting("Points", 20, 8, 40, 2));
    public final NumberSetting spokes = add(new NumberSetting("Spokes", 4, 0, 8, 1));
    public final NumberSetting speed = add(new NumberSetting("Spin speed", 0.12, 0.0, 0.5, 0.02));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", true));

    public ChinaHatModule() { super("China Hat", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (thirdPersonOnly.get() && c.options.getPerspective().isFirstPerson()) return;

        var effect = Fx.style(style);
        double base = p.getY() + p.getHeight() + 0.05;
        double h = height.get(), r = radius.get();
        double cx = p.getX(), cz = p.getZ();

        // Rim ring.
        int n = (int) points.get();
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            Fx.spawn(c, effect, cx + Math.cos(a) * r, base, cz + Math.sin(a) * r);
        }

        // Rotating spokes from the rim up to the tip.
        int sp = (int) spokes.get();
        double spin = p.age * speed.get();
        for (int s = 0; s < sp; s++) {
            double a = spin + 2 * Math.PI * s / sp;
            for (int k = 1; k <= 3; k++) {
                double t = k / 4.0; // 0 = rim, 1 = tip
                double rr = r * (1 - t);
                Fx.spawn(c, effect, cx + Math.cos(a) * rr, base + h * t, cz + Math.sin(a) * rr);
            }
        }
        Fx.spawn(c, effect, cx, base + h, cz); // tip
    }
}
