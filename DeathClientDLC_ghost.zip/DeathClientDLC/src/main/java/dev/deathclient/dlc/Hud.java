package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Top-center "Dynamic Island" status pill, an active-effects row below it, and a top-right module list. */
final class Hud {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFFAAAAAA;
    private static final String[] ROMAN = {"", " I", " II", " III", " IV", " V"};

    /** Toggled by the ".spec" chat command: hides every DeathClientDLC overlay (island, effects, list). */
    static boolean hidden;

    private Hud() {}

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        DynamicIslandModule isl = ModuleManager.get(DynamicIslandModule.class);
        if (isl == null || !isl.isEnabled()) return;

        var tr = c.textRenderer;
        List<String> seg = new ArrayList<>();
        if (isl.showClock.get()) seg.add(LocalTime.now().format(CLOCK));
        seg.add("Death Client");
        seg.add(Theme.current().label);
        if (isl.showConfig.get()) seg.add(Config.currentName());
        String line = String.join("   ", seg);

        int pad = 10, h = 16;
        int w = tr.getWidth(line) + pad * 2;
        int x = (c.getWindow().getScaledWidth() - w) / 2, y = 4;
        ClickGuiScreen.rect(ctx, x, y, w, h, BG, true, true);
        ClickGuiScreen.rect(ctx, x, y + h - 2, w, 2, Theme.current().accent(), false, true);
        ctx.drawTextWithShadow(tr, line, x + pad, y + 4, WHITE);

        if (isl.showEffects.get()) renderEffects(ctx, c, x + w / 2, y + h + 4);
        renderList(ctx, c);
    }

    private static void renderEffects(DrawContext ctx, MinecraftClient c, int cx, int top) {
        var tr = c.textRenderer;
        List<StatusEffectInstance> effects = new ArrayList<>(c.player.getStatusEffects());
        if (effects.isEmpty()) return;
        int y = top;
        for (StatusEffectInstance e : effects) {
            String name = Text.translatable(e.getEffectType().value().getTranslationKey()).getString();
            int amp = Math.max(0, Math.min(e.getAmplifier() + 1, ROMAN.length - 1));
            int seconds = Math.max(0, e.getDuration() / 20);
            String text = name + ROMAN[amp] + "  " + (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            int w = tr.getWidth(text) + 12;
            int x = cx - w / 2;
            ClickGuiScreen.rect(ctx, x, y, w, 12, BG, true, true);
            ctx.drawTextWithShadow(tr, text, x + 6, y + 2, MUTED);
            y += 14;
        }
    }

    private static void renderList(DrawContext ctx, MinecraftClient c) {
        var tr = c.textRenderer;
        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.isEnabled() && m.getCategory() != Category.MISC) active.add(m);
        active.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.getName())).reversed());
        int y = 4;
        int right = c.getWindow().getScaledWidth() - 6;
        int accent = Theme.current().accent();
        for (Module m : active) {
            String n = m.getName();
            int w = tr.getWidth(n);
            ctx.drawTextWithShadow(tr, n, right - w, y, accent);
            y += 10;
        }
    }
}
