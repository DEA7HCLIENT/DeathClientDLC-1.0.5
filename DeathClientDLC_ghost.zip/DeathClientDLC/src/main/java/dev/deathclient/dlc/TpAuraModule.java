package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Teleport aura: goes to the target (10-50 blocks away), hits it and goes back.
 * Position packets are sent in steps of at most STEP blocks; needs a collision-free straight line.
 * Visible = on: you really stand at the target for one tick before returning, so the teleport is seen.
 * Visible = off: everything happens server-side within one tick, your screen does not move.
 */
public class TpAuraModule extends Module {
    /** Max distance per movement packet; vanilla rejects roughly >10 blocks in one packet. */
    private static final double STEP = 8.0;
    private static final double REACH = 3.0;
    private static final int MAX_CANDIDATES = 5;

    public final NumberSetting range = add(new NumberSetting("Range", 30, 10, 50, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting visible = add(new BoolSetting("Visible", true));

    /** Set while we stand at the target and still owe the return trip (visible mode). */
    private Vec3d returnTo;

    public TpAuraModule() { super("TPAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (returnTo != null) {          // phase 2: go back
            finishReturn(p);
            return;
        }
        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;

        List<LivingEntity> candidates = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (p.distanceTo(le) <= range.get()) candidates.add(le);
        }
        candidates.sort(Comparator.comparingDouble(p::distanceTo));

        Vec3d start = Util.pos(p);
        int tried = 0;
        for (LivingEntity target : candidates) {
            if (tried++ >= MAX_CANDIDATES) break;
            if (p.distanceTo(target) <= REACH) {
                hit(c, p, target);
                return;
            }
            Vec3d goal = Util.pos(target);
            List<Vec3d> there = path(start, goal);
            if (!isClear(c, p, there)) continue;

            for (Vec3d v : there) send(p, v, false);
            hit(c, p, target);

            if (visible.get()) {
                p.setPosition(goal.x, goal.y, goal.z);   // stay here for one tick, return next tick
                returnTo = start;
            } else {
                sendBack(p, goal, start);
            }
            return;
        }
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null && returnTo != null) finishReturn(p);
        returnTo = null;
    }

    private void finishReturn(ClientPlayerEntity p) {
        Vec3d goal = Util.pos(p);
        Vec3d back = returnTo;
        returnTo = null;
        sendBack(p, goal, back);
        p.setPosition(back.x, back.y, back.z);
    }

    private static void sendBack(ClientPlayerEntity p, Vec3d from, Vec3d to) {
        List<Vec3d> back = path(from, to);
        for (int i = 0; i < back.size(); i++) {
            send(p, back.get(i), i == back.size() - 1 && p.isOnGround());
        }
    }

    private static void hit(MinecraftClient c, ClientPlayerEntity p, LivingEntity target) {
        c.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    /** Points from (excluded) to to (included), at most STEP apart. */
    private static List<Vec3d> path(Vec3d from, Vec3d to) {
        int n = Math.max(1, (int) Math.ceil(from.distanceTo(to) / STEP));
        List<Vec3d> points = new ArrayList<>(n);
        for (int i = 1; i <= n; i++) points.add(from.lerp(to, (double) i / n));
        return points;
    }

    private static boolean isClear(MinecraftClient c, ClientPlayerEntity p, List<Vec3d> points) {
        for (Vec3d v : points) {
            if (!c.world.isSpaceEmpty(p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ()))) {
                return false;
            }
        }
        return true;
    }

    private static void send(ClientPlayerEntity p, Vec3d v, boolean onGround) {
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(v.x, v.y, v.z, onGround, false));
    }
}
