package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;

/** Rotates the real player yaw every tick (camera and server rotation). */
public class SpinModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 30, 5, 90, 5));

    public SpinModule() { super("Spin", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        c.player.setYaw(c.player.getYaw() + (float) speed.get());
    }
}
